package maven;

public class Hello {
	
	public Hello() {
		System.out.println("Hello world!");
	}
	
	public boolean isAlive() {
		return true;
	}
}
